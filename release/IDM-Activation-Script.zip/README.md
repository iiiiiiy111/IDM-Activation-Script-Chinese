# IDM 激活脚本中文版（IDM Activation Script · Simplified Chinese Edition）

[![Windows validation](https://github.com/tytsxai/IDM-Activation-Script-Chinese/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/tytsxai/IDM-Activation-Script-Chinese/actions/workflows/ci.yml)
[![License: GPL v3](https://img.shields.io/badge/License-GPL_v3-blue.svg)](./LICENSE)
[![Version](https://img.shields.io/badge/version-v1.4.1-brightgreen.svg)](./CHANGELOG.md)
[![Platform](https://img.shields.io/badge/platform-Windows%207%20%7C%208%20%7C%2010%20%7C%2011-blue.svg)](#系统要求)
[![Release](https://img.shields.io/github/v/release/tytsxai/IDM-Activation-Script-Chinese)](https://github.com/tytsxai/IDM-Activation-Script-Chinese/releases)

[简体中文 (current)](README.md) · [English README](README.en.md) · [llms.txt for AI search](llms.txt) · [Docs](docs/README.md) · [Open Source Policy](OPEN_SOURCE_POLICY.md) · [Changelog](CHANGELOG.md) · [Issues](https://github.com/tytsxai/IDM-Activation-Script-Chinese/issues)

> **For English speakers**: see the [English README](README.en.md). This repo is the Simplified Chinese edition of [lstprjct/IDM-Activation-Script](https://github.com/lstprjct/IDM-Activation-Script). All scripts are GBK-encoded with Chinese menus, designed for Chinese Windows users who otherwise hit GBK/CP936 console garbling. Modes: **activation** (menu `[2]`, recommended — works immediately, no account or trial needed), **freeze trial** (menu `[1]`, fallback), **trial reset** (menu `[3]`), and since v1.4.0 **disable/restore IDM's auto-update check** (menu `[4]` / `[5]`) so IDM stops nagging about new versions. Pure batch + a tiny PowerShell helper, no IDM binary patching, automatic registry backup.

> **一键激活 Internet Download Manager（IDM）的中文脚本工具**：支持 IDM 冻结试用期、随机注册信息激活、试用期一键重置三种模式，并可一键禁用 / 恢复 IDM 的自动更新检查（不再反复弹更新窗），全程中文菜单与提示，无需安装任何依赖，单个 `.cmd` 文件即可在 Windows 7 / 8 / 10 / 11 上稳定运行。

## 项目简介 / Overview

**IDM 激活脚本中文版**（IDM Activation Script · Simplified Chinese Edition）是 [lstprjct/IDM-Activation-Script](https://github.com/lstprjct/IDM-Activation-Script) 的简体中文维护分支：全中文菜单、GBK/CP936 控制台编码、一键入口，把 Internet Download Manager（IDM）的**试用期冻结、随机注册信息激活、试用状态重置、关闭自动更新检查**封装成一个双击即用的批处理工具。不修改 IDM 程序文件，每次改注册表前自动备份，可离线运行。

| 项目 | 说明 |
| --- | --- |
| **是什么** | 面向中文 Windows 的 Internet Download Manager（IDM）激活与试用期管理批处理脚本 |
| **解决什么** | 英文 IDM 脚本在中文 CMD/PowerShell 里乱码；新手不知道该运行哪个文件、要不要管理员权限、怎么处理 SmartScreen/Defender 拦截；激活或试用状态异常后缺一个可回退、可排查的处理流程 |
| **适合谁** | 中文 Windows 7 / 8 / 8.1 / 10 / 11 用户；以及想研究 Windows 批处理、注册表操作、GBK/CP936 控制台兼容的开发者 |
| **核心功能** | `[1]` 冻结试用期 · `[2]` 随机注册信息激活 · `[3]` 重置激活/试用 · `[4]`/`[5]` 禁用/恢复 IDM 自动更新检查 · 运行前环境自检 · 注册表自动备份可还原 |
| **技术栈** | Windows Batch/CMD · PowerShell（UAC 提权、环境探测）· Windows 注册表 / WMI / CIM · GBK / CP936 + CRLF · GitHub Actions（`windows-latest`）CI |
| **支持平台** | Windows 7 / 8 / 8.1 / 10 / 11（含 24H2）；仅 Windows，macOS / Linux 不支持 |
| **许可证** | GPL-3.0，公开可审查、可自由再分发 |
| **不包含** | 不含 IDM 安装包，不修改 IDM 程序文件，不绕过企业策略（WDAC / AppLocker） |

**核心入口**

| 文件 | 用途 |
| --- | --- |
| `开始激活.cmd` | **唯一需要双击的主文件**：自动请求管理员权限 → 环境自检 → 弹出菜单（冻结 / 激活 / 重置 / 禁用更新提示任选） |
| `IAS.cmd` | 核心引擎，被 `开始激活.cmd` 调用；也支持 `/frz` `/act` `/res` `/noupd` `/reupd` `/silent` `/log=` 参数 |

> 从 v1.3.6 起，原来的四个脚本已合并为一个 `开始激活.cmd`，新手只需双击它。

**限制与注意**

- 会修改 IDM 相关注册表键（运行前自动备份、可还原），建议只在自己可控的设备上使用。
- SmartScreen / Defender / 第三方杀软可能拦截未签名批处理，属常见误报；可先校验 SHA256 再运行。
- 企业环境的 WDAC / AppLocker 策略会拦截未签名脚本，这是 IT 策略层面的限制，应联系管理员而非绕过。
- 请在合法授权且理解风险的前提下使用，遵守当地法律法规与 IDM 软件许可协议。

## 📥 快速下载

> **👉 直接下载按钮（推荐）**：[前往 GitHub Releases 页面下载最新版](https://github.com/tytsxai/IDM-Activation-Script-Chinese/releases/latest)  
> 页面中 `Assets` 区域的 `.zip` 文件即为安装包，点击即下载。

也可以在本仓库内直接下载（右键"链接另存为"）：

- 最新版压缩包（点击右键另存为）：[IDM-Activation-Script.zip](https://github.com/tytsxai/IDM-Activation-Script-Chinese/raw/main/release/IDM-Activation-Script.zip)
- 校验值（SHA256）：[IDM-Activation-Script.zip.sha256](https://github.com/tytsxai/IDM-Activation-Script-Chinese/raw/main/release/IDM-Activation-Script.zip.sha256)
- 完整更新历史：[CHANGELOG.md](./CHANGELOG.md)

> 压缩包**固定叫 `IDM-Activation-Script.zip`，不带版本号**（v1.4.1 起），所以上面两个链接永远指向最新版，不用每次发版换链接。当前版本号见页首徽章、[CHANGELOG.md](./CHANGELOG.md) 或运行脚本时的窗口标题。

> 安全起见建议校验：下载后在 PowerShell 中执行 `Get-FileHash .\IDM-Activation-Script.zip -Algorithm SHA256`，与 `.sha256` 文件内的值比对一致后再解压使用。若嫌麻烦，校验可略过。

## 📋 目录

- [项目简介 / Overview](#项目简介--overview)
- [快速下载](#快速下载)
- [功能特性](#功能特性)
- [系统要求](#系统要求)
- [使用方法](#使用方法)
- [功能说明](#功能说明)
- [常见问题](#常见问题)
- [技术细节](#技术细节)
- [文件说明](#文件说明)
- [更新日志](#更新日志)
- [维护与贡献](#维护与贡献)
- [相关链接](#相关链接)
- [免责声明](#免责声明)
- [许可证](#许可证)
- [版本与维护](#版本与维护)

## ✨ 功能特性

- ✅ **IDM 6.x 常见版本兼容** - 基于现有注册表结构维护，更新 IDM 后可重新运行冻结或重置流程
- ✅ **三种激活模式** - 冻结激活、普通激活、重置功能
- ✅ **可关闭 IDM 更新弹窗** - 一键禁用/恢复 IDM 自动更新检查，顺带避免升级后激活失效
- ✅ **中文显示优化** - 全部批处理/文本使用 GBK 编码，运行时强制 `chcp 936`，避免控制台乱码
- ✅ **自动备份** - 安全备份注册表，随时可恢复
- ✅ **智能检测** - 自动检测系统环境和 IDM 状态
- ✅ **环境自检** - 附带环境检测脚本（管理员/PowerShell/Null 服务/网络/代码页）
- ✅ **无需破解** - 不修改 IDM 程序文件
- ✅ **开源可审查** - GPL-3.0 许可，脚本和发布说明均可公开审查

> ⚠️ 提示：脚本文件使用 GBK 编码（便于 Windows 控制台显示），在 GitHub/Web IDE 中查看可能出现乱码，可用支持 GBK 的编辑器或 `iconv`。

## 💻 系统要求

| 项目 | 要求 |
|------|------|
| 操作系统 | Windows 7 / 8 / 8.1 / 10 / 11（含 24H2） |
| 权限 | **管理员权限**（脚本会自动请求，无需手动设置） |
| 依赖 | PowerShell（Windows 系统自带，无需额外安装） |
| 网络 | 能访问 internetdownloadmanager.com 即可（关闭 VPN/代理再试） |
| 编码 | 中文控制台（脚本自动执行 `chcp 936`，**无需手动设置**） |

## 🚀 使用方法

> 懒人两步：解压后双击 `开始激活.cmd` → 在弹出的"是"窗口里授予管理员权限 → 它会先自检环境，再弹出菜单，**按数字选 `[2]` 激活（推荐，直接可用）** 即可；若之后 IDM 仍提示未注册，再改选 `[1]` 冻结激活。  
> 小贴士：`开始激活.cmd` 进菜单前会一次检查管理员权限、PowerShell 语言模式、Null 服务、网络连通性、代码页、WMI、IDM 路径与当前目录写权限，全程仅需本仓库文件。

> ### ⚠️ 第一次运行前必看
>
> 1. **必须以管理员身份运行**。`开始激活.cmd` 会自动弹出 UAC 提权窗口，点"**是**"即可。
> 2. **Windows 可能弹出"已阻止"或"Windows 已保护你的电脑"**（SmartScreen）。这是对未签名批处理脚本的标准提示，不是脚本真的有问题。处理方法：
>    - SmartScreen 弹窗：点 **"更多信息"** → **"仍要运行"**；
>    - 文件属性里若出现"此文件来自其他计算机，可能会阻止此文件"，在文件上右键 → **属性** → 底部勾选"**解除锁定**" → 确定。
> 3. **杀软（Defender/360/火绒）可能报毒**。本脚本涉及注册表写入和提权，属于启发式引擎的常规误报。若信任本仓库的发布包（SHA256 已公布），可把解压目录临时加入杀软白名单再运行。

### 方法一：图形界面（推荐新手）

1. **双击** `开始激活.cmd`（会自动请求管理员权限；若没弹窗，可右键 → "以管理员身份运行"）
2. **等待环境自检完成**，随后自动进入菜单
3. **按数字选择**（推荐 `[2]` 激活，直接可用；若仍提示未注册再用 `[1]` 冻结）

```
┌─────────────────────────────────────┐
│   IDM 激活脚本主菜单                 │
├─────────────────────────────────────┤
│  [1] 激活（冻结）                   │
│  [2] 激活            ⭐ 推荐         │
│  [3] 重置激活/试用期                 │
│  [4] 禁用 IDM 更新提示               │
│  [5] 恢复 IDM 更新提示               │
│  [6] 下载 IDM                       │
│  [7] 帮助                           │
│  [0] 退出                           │
└─────────────────────────────────────┘
```

<details>
<summary><b>方法二：命令行（高级用户，新手可以跳过）</b></summary>

以管理员身份打开 CMD，然后运行：

```cmd
# 激活（推荐，直接可用）
IAS.cmd /act

# 冻结激活（激活后仍提示未注册时改用）
IAS.cmd /frz

# 重置激活
IAS.cmd /res

# 禁用 IDM 自动更新检查（不再弹"发现新版本"）
IAS.cmd /noupd

# 恢复 IDM 自动更新检查
IAS.cmd /reupd

# 静默模式 + 日志（无人值守）
IAS.cmd /act /silent /log="C:\Temp\ias.log"
```

> 说明：`/silent` 抑制菜单与等待，`/log=路径` 记录运行日志；未带 `/frz` `/act` `/res` `/noupd` `/reupd` 即开启静默将返回码 2。同时给 `/noupd` 和 `/reupd` 时以 `/noupd` 为准。

</details>

## 📖 功能说明

> **怎么选？看你当前的状态：**
> - **没有领取 30 天试用期 / 想直接能用** → 选 `[2]` **激活**（最常见，推荐）
> - **已经领取并正在使用 30 天试用期**（有 IDM 账号、点过"开始试用"）→ 选 `[1]` **冻结激活**（把当前试用期冻住，不让它到期）
> - 选 `[2]` 激活后 IDM 仍提示"未注册" → 改用 `[1]` 冻结作为兜底

### 🌟 激活（菜单 `[2]`）[最常用]

- **功能**：写入注册信息直接激活 IDM，激活后即可正常使用
- **优点**：最简单直接、立即可用，**不需要账号、也不需要先领试用期**
- **适用**：没领过试用期、或只想让 IDM 直接能用的用户

### ❄️ 激活（冻结）（菜单 `[1]`）

- **功能**：将 IDM 当前的 30 天试用期冻结住，不写入序列号
- **前提**：你已经领取（激活）了 30 天试用期——冻结就是把这个试用期固定下来不让它过期
- **优点**：不会触发"假阳性序列号"，在 IDM 6.42+ 上最稳定、最不容易再弹注册窗
- **适用**：正在用试用期的用户；或用 `[2]` 激活后仍被提示"未注册"时的兜底

### 🔄 重置激活/试用期

- **功能**：清除所有激活信息，恢复初始状态
- **用途**：解决激活异常、更换激活方式

### 🔕 禁用 / 恢复 IDM 更新提示（菜单 `[4]` / `[5]`，v1.4.0 新增）

- **功能**：把注册表 `HKCU\Software\DownloadManager` 下的 `CheckUpdtVM` 置为 `0`（`[5]` 改回 `1`），关闭 IDM 的自动更新检查
- **效果**：IDM 不再反复弹"发现新版本 / 请更新"的提示窗；也不会自动升级到新版本导致激活失效
- **代价**：停留在当前版本后，不再获得官方的修复与新功能；想更新时先选 `[5]` 恢复即可
- **说明**：只改这一个开关值，不写序列号、不动 CLSID，与激活状态互不影响；执行前会先关闭正在运行的 IDM 让设置生效

## ❓ 常见问题

<details>
<summary><b>Q1: 提示"需要管理员权限"怎么办？</b></summary>

**解决方法：**
- 右键脚本文件
- 选择"以管理员身份运行"
- 不要直接双击运行

</details>

<details>
<summary><b>Q2: 提示"IDM 未安装"？</b></summary>

**解决方法：**
1. 先确认 `IDMan.exe` 已存在，常见路径是 `C:\Program Files (x86)\Internet Download Manager\IDMan.exe` 或 `C:\Program Files\Internet Download Manager\IDMan.exe`。
2. 自检里显示的 `HKLM\SOFTWARE\...\Internet Download Manager` 是 Windows 注册表项名称，不是网络连接；关闭互联网不会改变这个结果。
3. 如果自检提示"未在注册表找到 IDM 安装路径"，通常是 IDM 安装不完整、绿色版未写注册表，或当前用户下的 `ExePath` 没有写入。请先重新安装官方 IDM，再运行 `开始激活.cmd`。
4. 官方下载：https://www.internetdownloadmanager.com/download.html

</details>

<details>
<summary><b>Q3: 激活后仍提示注册？</b></summary>

**解决方法：**
1. 改用 `[1]` "激活（冻结）"选项——它不写序列号，最不容易被 IDM 判定为"假序列号"而重复弹注册窗
2. 或先选 `[3]` "重置激活"，再重新选 `[2]` 激活
3. 完全卸载 IDM 后重新安装，再激活

</details>

<details>
<summary><b>Q4: 中文显示为乱码？</b></summary>

**解决方法：**
1. 菜单与提示均为 GBK + `chcp 936`，正常中文系统不会乱码。v1.3.6 还修复了旧版控制台（"使用旧版控制台"勾选时）下激活过程中个别带颜色提示走 PowerShell 输出导致的乱码——现在这种情况会以无颜色的纯文本正确显示中文。
2. 如仍有个别乱码，在 CMD 中运行 `chcp 936` 后重试。
3. 确保系统区域设置为中国或简体中文。

</details>

<details>
<summary><b>Q5: 提示"无法连接到 internetdownloadmanager.com"？</b></summary>

**解决方法：**
1. 检查网络连接
2. 关闭 VPN 或代理
3. 配置系统代理设置
4. 临时关闭防火墙测试

</details>

<details>
<summary><b>Q6: PowerShell 被组织策略禁用？</b></summary>

**解决方法：**
- 联系本机/域管理员解除限制
- 在 PowerShell 终端执行 `Set-ExecutionPolicy RemoteSigned`（需管理员权限）
- 如为公司设备，建议在个人设备上使用

</details>

<details>
<summary><b>Q7: Windows 11 24H2 上脚本是否可用？</b></summary>

**解决方法：**
- 24H2 默认启用 SmartScreen 与云保护，首次运行时可能弹出"已阻止"提示
- 右键 `开始激活.cmd` → 属性 → 底部勾选"解除锁定"，再以管理员身份运行
- 若 PowerShell 在 ConstrainedLanguage 模式下被限制，`开始激活.cmd` 的环境自检会明确指出对应检查项失败，按提示处理即可

</details>

<details>
<summary><b>Q8: Windows Defender / 第三方杀软拦截脚本？</b></summary>

**解决方法：**
- 本脚本涉及注册表写入、WMI 查询与 PowerShell 提权，启发式引擎可能产生误报
- 如果信任本仓库发布的 `release` 产物（可用 `release/IDM-Activation-Script.zip.sha256` 校验），可把解压目录加入 Defender 排除项再运行
- 校验命令：PowerShell 里 `Get-FileHash IDM-Activation-Script.zip -Algorithm SHA256`，与 `.sha256` 文件内容比对

</details>

<details>
<summary><b>Q9: 企业环境启用了 WDAC / AppLocker，脚本直接拒绝执行？</b></summary>

**解决方法：**
- WDAC 或 AppLocker 策略通常会阻止未签名脚本运行，这是企业 IT 的策略层拦截，不是脚本本身的问题
- 正确处理方式是联系 IT 获取授权，不建议绕过
- 个人设备上不存在此问题

</details>

<details>
<summary><b>Q10: IDM 6.42 / 6.43 等较新版本是否兼容？</b></summary>

**解决方法：**
- 本脚本基于 IDM 注册表 CLSID 结构工作，IDM 6.x 系列整体保持兼容
- 若更新 IDM 后发现激活失效，建议先在菜单选 `[3]` 执行"重置激活"（或 `IAS.cmd /res`），再重新选择 `[2]` "激活"；若激活后仍提示未注册，改用 `[1]` "冻结激活"
- 仍不生效时，请在 Issue 中带上 `开始激活.cmd` 的环境检测输出与 IDM 具体版本号

</details>

<details>
<summary><b>Q11: 冻结或激活后 IDM 自己又启动，是脚本一直在后台运行吗？</b></summary>

**说明与处理：**
- 脚本不是常驻程序，执行完成后不会留后台进程。
- 冻结/激活流程可能会短暂启动 IDM 做状态验证；如果 IDM 之后又自己出现，通常是 IDM 自身的启动项、托盘驻留、浏览器集成或计划任务行为。
- 可以在 IDM 设置里关闭"开机启动"/托盘相关选项，并在任务管理器的"启动应用"里确认 IDM 没有被设置为开机启动。
- 如仍异常，请在 Issue 中补充 `开始激活.cmd` 完整环境检测输出、实际运行入口、IDM 版本和复现步骤；只写 `1` 或空日志无法判断脚本问题。

</details>

<details>
<summary><b>Q12: 脚本一直卡在"正在初始化…"不动怎么办？</b></summary>

**原因：** "正在初始化…"之后脚本会做系统信息探测（WMI/CIM）、获取用户 SID、校验注册表访问。个别新版 Windows（如 Win11 24H2/25H2）上，旧版 `Get-WmiObject`（走 DCOM/RPC）在 WMI 仓库异常或被安全软件挂钩时可能长时间卡住，看起来就是"卡在初始化"。

**解决方法：**
1. 升级到 **v1.3.9 及以上**：已把系统信息探测改为优先 `Get-CimInstance`，失败才回退旧版 WMI，并在初始化时打印分步进度（`检测系统信息` / `获取用户账户 SID` / `校验注册表访问`），卡住时能一眼看出卡在哪一步。
2. 若仍卡住，多为本机 WMI 仓库损坏：管理员 CMD 里执行 `winmgmt /verifyrepository`，异常时 `net stop winmgmt` 后 `winmgmt /salvagerepository`，再重试。
3. 临时退出杀毒/安全软件的实时防护后重试，排除其对 WMI/PowerShell 的挂钩。
4. 反馈时请附上卡住时脚本显示到哪一行进度，便于定位。

</details>

<details>
<summary><b>Q13: 用 [2] 激活后弹出"假序列号已被封锁 / 请购买 IDM / 剩余 0 天"怎么办？</b></summary>

**原因：** `[2]` 激活会写入一个随机序列号；IDM 联网校验后可能把它判定为"假序列号"，从而弹出提示并回落到试用/购买页面。这是随机序列号方式的固有风险，并非脚本出错。

**解决方法：**
1. 改用 `[1]` **激活（冻结）**：它**不写入任何序列号**，而是冻结 IDM 的试用期跟踪，不会触发联网序列号校验，因此不会再被判"假序列号"，在 IDM 6.42+ 上最稳定。
2. 切换前先选 `[3]` **重置激活**清掉旧的随机序列号，再选 `[1]` 冻结。
3. 若之前已领取并在用 30 天试用期，直接用 `[1]` 冻结把试用期固定住即可。

</details>

<details>
<summary><b>Q14: 激活后浏览器打不开某些网页（如 1panel 面板/内网管理页），重置后恢复正常？</b></summary>

**说明：** 本脚本**不修改 hosts、防火墙、系统代理，也不拦截任何网络**，只操作 IDM 相关注册表项。因此这类"某些网页打不开"通常来自 **IDM 浏览器集成模块**：激活后 IDM 处于工作状态，其浏览器扩展会监控页面请求，遇到长连接/流式响应/特定资源（部分面板类页面）时可能接管或干扰，导致页面加载异常；`[3]` 重置后 IDM 回到未激活状态、集成模块不再介入，于是恢复。

**解决方法：**
1. 在浏览器里**临时停用 IDM Integration Module 扩展**，或在 IDM → 选项 → 常规 里取消勾选对应浏览器的集成，再访问该页面验证。
2. 在 IDM → 选项 → 站点管理 / 文件类型 里，把该面板域名或该类型加入**不接管**列表。
3. 若确认与 IDM 集成无关（停用扩展仍打不开），请在 Issue 中附上该页面地址类型、浏览器版本与是否走了代理，便于进一步排查。

</details>

<details>
<summary><b>Q15: IDM 老是弹"发现新版本/请更新"，能不能关掉？（v1.4.0 起支持）</b></summary>

**说明：** IDM 默认会定期联网检查新版本并弹窗提示；而且一旦真的升级到新版，本脚本写入的激活状态经常会失效，需要重新运行一次。

**解决方法：**
1. 运行 `开始激活.cmd`，在菜单里选 **`[4]` 禁用 IDM 更新提示**（命令行等价：`IAS.cmd /noupd`）。脚本会把注册表 `HKCU\Software\DownloadManager` 下的 `CheckUpdtVM` 置为 `0`，IDM 就不再自动检查更新，也不会再弹更新窗。
2. 需要恢复时选 **`[5]` 恢复 IDM 更新提示**（`IAS.cmd /reupd`），该值会改回 `1`。
3. 执行时脚本会先结束正在运行的 `IDMan.exe`，设置在 IDM 下次启动时生效；如果弹窗仍出现，先确认 IDM 已完全退出（托盘图标也要退出）再重开。
4. 这一步只改更新检查开关，不写序列号、不动 CLSID，不会影响已有的激活或冻结状态。

</details>

## 🔧 技术细节

### 工作原理

1. **锁定/删除** CLSID 注册表键
2. **注入随机** 注册信息（激活模式）
3. **下载测试** 文件验证 IDM 功能
4. **冻结试用期**（冻结模式）
5. **更新开关**：`CheckUpdtVM` 置 0 / 1，关闭或恢复 IDM 的自动更新检查

### 注册表备份

脚本会自动备份注册表到以下位置：

```
C:\Windows\Temp\_Backup_HKCU_CLSID_[时间戳].reg
C:\Windows\Temp\_Backup_HKU-[SID]_CLSID_[时间戳].reg
```

**恢复方法：** 双击 `.reg` 文件即可导入恢复

### 编码说明

- 所有 `.cmd`/`.txt` 文件使用 GBK（代码页 936）保存，并在运行时强制切换控制台到相同代码页以保证中文显示。
- 在 UTF-8 环境下阅读源码，可使用 `iconv -f GBK -t UTF-8 IAS.cmd`（或替换为其他文件名）或支持 GBK 的文本编辑器。
- 仓库通过 `.gitattributes` 固定 `.cmd`/`.txt` 为 CRLF 行尾，避免批处理因 LF 换行导致的校验错误。

### 安全性

- ✅ 不修改 IDM 程序文件
- ✅ 仅修改注册表配置
- ✅ 自动备份，可随时恢复
- ✅ 开源透明，代码可审查

## 📦 文件说明

| 文件名 | 说明 |
|--------|------|
| `开始激活.cmd` | **新手唯一需要双击的主文件**：自动请求管理员权限 → 环境自检 → 弹出菜单（冻结 / 激活 / 重置 / 禁用更新提示） |
| `IAS.cmd` | 核心引擎（批处理，GBK 编码），被 `开始激活.cmd` 调用；也支持 `/frz` `/act` `/res` `/noupd` `/reupd` `/silent` `/log=` 参数 |
| `使用说明.txt` | 极简上手指南（UTF-8，Windows 记事本即可查看） |
| `README.md` | 当前完整图文说明 |
| `CHANGELOG.md` | 全部历史版本的详细变更记录 |

## 📝 更新日志

> 完整历史变更请查看 [`CHANGELOG.md`](./CHANGELOG.md)。下方仅保留最近几个版本的摘要。

### v1.4.1 (当前版本) - 2026-07-24

- **发布包改用固定文件名 `IDM-Activation-Script.zip`**（不带版本号）：以前每发一版就多一个 `IDM-Activation-Script-v<版本>.zip`，README / `llms.txt` / `README.en.md` 的下载链接每次都要跟着改，漏改就会指向旧包。现在链接一次写死、永远指向最新版；版本号由 Git tag、Release 标题、`CHANGELOG.md` 和 `IAS.cmd` 的 `iasver` 标识。
- **`release/` 只保留一份最新发布包**：历史版本改由 [GitHub Releases](https://github.com/tytsxai/IDM-Activation-Script-Chinese/releases) 各 tag 页面的 Assets 长期提供，仓库内副本可在 Git 历史中找回；新增 `release/README.md` 说明该约定。
- `IAS.cmd` 版本号 `1.4.0` → `1.4.1`，保持脚本自报版本与 tag、发布包一致。
- **脚本逻辑零改动**，功能与 v1.4.0 完全一致。

### v1.4.0 - 2026-07-24

- **新增"禁用 / 恢复 IDM 更新提示"**（对应 issue #20）：主菜单新增 `[4] 禁用 IDM 更新提示` 与 `[5] 恢复 IDM 更新提示`，命令行对应 `/noupd` 与 `/reupd`。实现方式是把 `HKCU\Software\DownloadManager` 下的 `CheckUpdtVM` 置为 `0`（恢复时置 `1`），IDM 便不再自动检查新版本、也不再反复弹更新窗；顺带避免 IDM 自动升级后激活失效。
- 菜单编号相应调整：`[6] 下载 IDM`、`[7] 帮助`，`[1]` `[2]` `[3]` 保持不变。
- 新增 FAQ **Q15**（关闭 IDM 更新提示的完整步骤与影响）。
- CI 增加冒烟用例：无 IDM 环境下 `IAS.cmd /noupd /silent` 应返回码 1。
- 运行时发布包更新为 `IDM-Activation-Script-v1.4.0.zip`。

### v1.3.9 - 2026-07-10

- **修复 `IAS.cmd` 在部分新版 Windows 上"卡在正在初始化"**（对应 issue #16）：初始化的系统信息探测与用户 SID 获取由旧版 `Get-WmiObject`（走 DCOM/RPC，在 Win11 24H2/25H2 上遇 WMI 仓库异常或安全软件挂钩时会卡死）改为**优先 `Get-CimInstance`、失败回退旧版 WMI**（保留 Win7/PS2 兼容），并与 v1.3.6 中 `开始激活.cmd` 自检的改法保持一致。
- **初始化分步进度提示**：新增 `检测系统信息` / `获取用户账户 SID` / `校验注册表访问` 三行输出，卡顿时可定位到具体步骤。
- **常见问题补充**：新增 Q12（初始化卡死）、Q13（`[2]` 激活后弹"假序列号"/购买页 → 改用 `[1]` 冻结，对应 issue #17）、Q14（激活后浏览器打不开 1panel 等页面 = IDM 浏览器集成干扰，脚本不改动网络，对应 issue #18）。
- 运行时发布包更新为 `IDM-Activation-Script-v1.3.9.zip`。

更早版本（v1.3.8 及之前）的完整变更见 [`CHANGELOG.md`](./CHANGELOG.md)。

## 🧰 维护与贡献

- 贡献指南：[CONTRIBUTING.md](./CONTRIBUTING.md)
- 架构 / 结构说明：[ARCHITECTURE.md](./ARCHITECTURE.md)
- 开源维护策略：[OPEN_SOURCE_POLICY.md](./OPEN_SOURCE_POLICY.md)
- 维护 / 发布检查清单：[docs/maintenance-checklist.md](./docs/maintenance-checklist.md)
- Windows 冒烟基线：[docs/reports/smoke-win-baseline.md](./docs/reports/smoke-win-baseline.md)
- 安全漏洞上报：[SECURITY.md](./SECURITY.md)
- CI 校验脚本：[tools/validate.ps1](./tools/validate.ps1)（在 GitHub Actions 的 `Windows validation` 工作流中执行）
- 编码 / 换行约束：[.gitattributes](./.gitattributes)（`*.cmd` / `*.txt` 为 GBK + CRLF；`*.md` / `*.yml` 为 UTF-8 + LF）

## 🌐 相关链接

- **项目主页**: https://github.com/tytsxai/IDM-Activation-Script-Chinese
- **IDM 官网**: https://www.internetdownloadmanager.com
- **问题反馈**: https://github.com/tytsxai/IDM-Activation-Script-Chinese/issues
- **AI 搜索索引**: [`llms.txt`](./llms.txt)
- **文档索引**: [`docs/README.md`](./docs/README.md)

## ⚠️ 免责声明

> **本脚本仅供学习和测试使用！**

- 本工具仅用于学习 Windows 注册表操作和批处理编程
- 请支持正版软件，购买官方授权
- 长期使用建议购买正版：https://www.internetdownloadmanager.com/buy_now.html

## 📄 许可证

本项目以 **GNU General Public License v3.0（GPL-3.0）** 开源发布，完整条款见仓库根目录的 `LICENSE` 文件。

本中文版本基于上游项目 [lstprjct/IDM-Activation-Script](https://github.com/lstprjct/IDM-Activation-Script) 演进，当前中文版本由本仓库独立维护。

使用、修改或再分发本项目时，需遵循 GPL-3.0 的基本要求：

- 可自由使用、学习、修改与再分发脚本；
- 二次发布必须保留 GPL-3.0 许可证文本、版权声明与修改记录；
- 基于本项目派生的作品需以相同或兼容的 GPL 许可证发布；
- 作者不对脚本使用过程中产生的任何直接或间接损失承担责任，详见 `LICENSE` 中"NO WARRANTY"条款。

## 🔄 版本与维护

- 当前版本 **v1.4.1**（2026-07-24），文档与运行时脚本包同步。核心功能：`[1]` 冻结、`[2]` 激活、`[3]` 重置、`[4]`/`[5]` 禁用/恢复 IDM 更新提示。
- 由本仓库独立维护，基于真实使用反馈持续迭代，保持 GPL-3.0 开源。
- 所有依赖都在仓库内，可离线运行；每次 push / PR 都会跑 Windows CI 校验编码、行尾与脚本冒烟（徽章见页首）。

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=tytsxai/IDM-Activation-Script-Chinese&type=Date)](https://www.star-history.com/#tytsxai/IDM-Activation-Script-Chinese&Date)
